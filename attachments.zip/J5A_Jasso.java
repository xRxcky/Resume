// Tax Demo Program - J5A_Jasso
// Ricardo Jasso - BCIS 3630.2

public class J5A_Jasso
{
   public static void main(String[] args)
   {
      FederalTax TaxPayer1 = new FederalTax();
      TaxPayer1.setTaxPayerID("001-11-1111");
      TaxPayer1.setMarStatus('M');
      TaxPayer1.setExemptAmt(1000);
      TaxPayer1.setIncomeAmt(40000);
      
      FederalTax TaxPayer2 = new FederalTax("002-22-2222");
      TaxPayer2.setMarStatus('M');
      TaxPayer2.setIncomeAmt(95000);
      TaxPayer2.setExemptAmt(2000);
      
      FederalTax TaxPayer3 = new FederalTax("003-33-3333");
      TaxPayer3.setMarStatus('M');
      TaxPayer3.setIncomeAmt("85000");
      TaxPayer3.setExemptAmt("1500");
      
      FederalTax TaxPayer4 = new FederalTax("004-44-4444", 'S', 25000, 500);
        
      System.out.println("Tax Payer #1:");
      System.out.println("Tax Payer ID: " + TaxPayer1.getTaxPayerID());
      System.out.println("Marital Status: " + TaxPayer1.getMarStatus());
      System.out.printf("Income Amt: $%,.2f%n",TaxPayer1.getIncomeAmt());
      System.out.printf("Exempt Amt: $%,.2f%n",TaxPayer1.getExemptAmt());
      System.out.printf("Fed Tax Amt: $%,.2f%n",TaxPayer1.getFedTaxAmt());
      
      System.out.println("\nTax Payer #2:");
      System.out.println("Tax Payer ID: " + TaxPayer2.getTaxPayerID());
      System.out.println("Marital Status: " + TaxPayer2.getMarStatus());
      System.out.printf("Income Amt: $%,.2f%n",TaxPayer2.getIncomeAmt());
      System.out.printf("Exempt Amt: $%,.2f%n",TaxPayer2.getExemptAmt());
      System.out.printf("Fed Tax Amt: $%,.2f%n",TaxPayer2.getFedTaxAmt());
      
      System.out.println("\nTax Payer #3:");
      System.out.println("Tax Payer ID: " + TaxPayer3.getTaxPayerID());
      System.out.println("Marital Status: " + TaxPayer3.getMarStatus());
      System.out.printf("Income Amt: $%,.2f%n",TaxPayer3.getIncomeAmt());
      System.out.printf("Exempt Amt: $%,.2f%n",TaxPayer3.getExemptAmt());
      System.out.printf("Fed Tax Amt: $%,.2f%n",TaxPayer3.getFedTaxAmt());
      
      System.out.println("\nTax Payer #4:");
      System.out.println("Tax Payer ID: " + TaxPayer4.getTaxPayerID());
      System.out.println("Marital Status: " + TaxPayer4.getMarStatus());
      System.out.printf("Income Amt: $%,.2f%n",TaxPayer4.getIncomeAmt());
      System.out.printf("Exempt Amt: $%,.2f%n",TaxPayer4.getExemptAmt());
      System.out.printf("Fed Tax Amt: $%,.2f%n",TaxPayer4.getFedTaxAmt());
   }
}

