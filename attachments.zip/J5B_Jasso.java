// Patient Demo - J5B_Jasso
// Ricardo Jasso - BCIS 3630

public class J5B_Jasso
{
   public static void main(String[] args)
   {
      PatientInfo patient1 = new PatientInfo();
      patient1.setFirstName("Nassaar");
      patient1.setLastName("Eydani");
      patient1.setPhone("(555)123-4567");
      patient1.setDiagnosisCode("J20.9");
      
      PatientInfo patient2 = new PatientInfo("Daniel", "Mavridis", "(555)-234-5678");
      patient2.setDiagnosisCode("G43.909");
      
      PatientInfo patient3 = new PatientInfo("Rebecca", "Knight", "(555)-345-1234", "F90.1");
      
      System.out.println("Patient 1");
      System.out.println("Name: " + patient1.getFirstName() + " " + patient1.getLastName());
      System.out.println("Phone: " + patient1.getPhone());
      System.out.println("Diagnosis Code: " + patient1.getDiagnosisCode());
      System.out.println("Diagnosis Description: " + patient1.getDiagnosisDescription());
      
      System.out.println("Patient 2");
      System.out.println("Name: " + patient2.getFirstName() + " " + patient2.getLastName());
      System.out.println("Phone: " + patient2.getPhone());
      System.out.println("Diagnosis Code: " + patient2.getDiagnosisCode());
      System.out.println("Diagnosis Description: " + patient2.getDiagnosisDescription());
      
      System.out.println("Patient 3");
      System.out.println("Name: " + patient3.getFirstName() + " " + patient3.getLastName());
      System.out.println("Phone: " + patient3.getPhone());
      System.out.println("Diagnosis Code: " + patient3.getDiagnosisCode());
      System.out.println("Diagnosis Description: " + patient3.getDiagnosisDescription());   
   }
}