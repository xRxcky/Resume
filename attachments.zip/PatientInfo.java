// Patient Info - J5B_Jasso
// Ricardo Jasso - BCIS 3630

public class PatientInfo
{
   private String firstName;
   private String lastName;
   private String phone;
   private String diagnosisCode;
   
   public PatientInfo()
   {
      firstName = "";
      lastName = "";
      phone = "";
      diagnosisCode = "";
   }
   public PatientInfo(String first, String last, String phon)
   {
      firstName = first;
      lastName = last;
      phone = phon;
   }
   public PatientInfo(String first, String last, String phon, String diagCode)
   {
      firstName = first;
      lastName = last;
      phone = phon;
      diagnosisCode = diagCode;
   }
   public void setFirstName(String first)
   {
      firstName = first;
   }
   public void setLastName(String last)
   {
      lastName = last;
   }
   public void setPhone(String phon)
   {
      phone = phon;
   }
   public void setDiagnosisCode(String diagCode)
   {
      diagnosisCode = diagCode;
   }
   public String getFirstName()
   {
      return firstName;
   }
    public String getLastName()
   {
      return lastName;
   }
    public String getPhone()
   {
      return phone;
   }
    public String getDiagnosisCode()
   {
      return diagnosisCode;
   }  
   public String getDiagnosisDescription()
   {
      switch(diagnosisCode)
      {
         case "J20.9":
            return "Bronchitis";
         case "J45.909":
            return "Asthma";
         case "F90.1":
            return "ADHD";
         case "G43.909":
            return "Migraine";
         case "J03.90":
            return "Tonsillitis";
         case "J01.90":
            return "Sinusitis";
         default:
            return "Unknown Diagnosis";
      }
   }
}