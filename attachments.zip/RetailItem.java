/*
RetailItem
**********
- description
- unitsOnHand
- price
*************
+ RetailItem()
+ RetailItem(desc String. units int, pri double)
+ setDescription(desc String) : void
+ setUnitsOnHand(units int) : void
+ setPrice(pri double) : void
+ getDescription() : String
+ getUntisOnHand() : int
+ getPrice() : double
*/

public class RetailItem
{
   private String description ;
   private int unitsOnHand ;
   private double price ;
   
   public RetailItem()
   {
      description = "";
      unitsOnHand = 0;
      price = 0.0;
   }
   
   public RetailItem(String desc, int units, double pri)
   {
      description = desc;
      unitsOnHand = units;
      price = pri;
   }
   public void setDescription(String desc)
   {
      description = desc;
   }
   public void setUnitsOnHand(int units)
   {
      unitsOnHand = units;
   }
   public void setPrice(double pri)
   {
      price = pri;
   }
   public String getDescription()
   {
      return description ;
   }
}