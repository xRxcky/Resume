// Phone Class Array - J6B_Jasso
// Ricardo Jasso - BCIS 3630.2

public class J6B_Jasso
{
   public static void main(String[] args)
   {
      Phone[] phones = new Phone[4];
      phones[0] = new Phone("Juan Olivarez", "J.Olivares@IBM.com", "2141");
      phones[1] = new Phone("Suphanne King", "S.King@Chase.com", "1231");
      phones[2] = new Phone("Soheyla Eydani", "S.Eydani@Citi.com", "2131");
      phones[3] = new Phone("Robb Dean", "R.Dean@BofA.com", "1241");
      
      double total = 0.0;
      System.out.printf("%-20s%-30s\t%-14s\t%-5s\t$%-8s\n", "Customer", "Email", "Phone", "Part#", "Price");
      for (int index = 0; index < phones.length; index++)
      {
         String name = phones[index].getCustName();
         String email = phones[index].getCustEmail();
         String phoneDesc = phones[index].getPhoneDesc();
         String partNum = phones[index].getPartNum();
         double price = phones[index].getPhonePrice();
         total += price;
         System.out.printf("%-20s%-30s\t%-14s\t%-5s\t$%,8.2f\n", name, email, phoneDesc, partNum, price);
      }
      System.out.printf("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tTotal:\t$%,8.2f\n", total);
   }
}

