// Restaurants - J6A_Jasso
// Ricardo Jasso - BCIS 3630.2

// import ArrayList
import java.util.ArrayList;

public class J6A_Jasso
{
   public static void main(String[] args)
   {
      ArrayList<String> restaurantList = new ArrayList<>();
      restaurantList.add("Avesta");
      restaurantList.add("Chili's");
      restaurantList.add("Eagle Landing");
      restaurantList.add("Firehouse Subs");
      restaurantList.add("Jason's Deli");
      restaurantList.add("Mean Greens");
      restaurantList.add("Outback Steakhouse");
      restaurantList.add("Texas Roadhouse");
      
      System.out.println("List of Restaurants");
      for (int index = 0; index < restaurantList.size(); index++)
      {
         System.out.println(restaurantList.get(index));
      }
      
      restaurantList.add(1, "Cheddars Kitchen");
      
      restaurantList.set(4, "Chipotle");
      restaurantList.set(6, "Pluckers");
      
      System.out.println("\nUpdated Restaurant List");
      for (int index = 0; index < restaurantList.size(); index++)
      {
         System.out.println(restaurantList.get(index));
      }
      
   }
}